By Light

How to install:
- Add the files from the folder named 'data' to your LF2 folder 'data';
- Add the files from folder named 'sys' to your LF2 folder 'sys';
- Add the following data lines to data.txt (in your LF2 data folder):
id: 499  type: 0  file: data\lighto.dat
id: 500  type: 1  file: data\lighto_wp.dat
id: 501  type: 3  file: data\lighto_shadow.dat
id: 502  type: 4  file: data\lighto_ball.dat 


Character: Lighto(ver1.1)
Skills: ice ball    D>A
        ice ball from sky Jump >A
Other: this character can not take any weapons


______________________________________________________________________

                          downloaded from:
            Little Fighter Empire -- The Official Fansite
                       http://www.lf-empire.de